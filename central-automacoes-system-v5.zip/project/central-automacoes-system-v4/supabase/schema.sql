create table if not exists automacoes (
  id uuid primary key default gen_random_uuid(),
  codigo text unique not null,
  nome text not null,
  area text not null,
  responsavel text,
  usuario text not null,
  email_usuario text,
  maquina text not null,
  tipo text not null,
  status text not null default 'Ativo',
  versao text,
  finalidade text,
  caminho_arquivo text,
  link_planilha text,
  arquivo_automacao text,
  observacoes text,
  data_entrega date,
  created_at timestamp with time zone default now()
);

create table if not exists usuarios_permissoes (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  email text unique not null,
  area text,
  perfil text not null default 'Visualizador',
  ativo boolean default true,
  created_at timestamp with time zone default now()
);
